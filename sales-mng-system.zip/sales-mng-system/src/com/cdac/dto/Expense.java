package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "expense")
public class Expense {
	@Id
	@Column(name = "expense_id")
	@GeneratedValue
	private int expenseId;
	@Column(name = "item_name")
	private String itemName;
	
	@Column(name = "item_price")
	private float price;
	
	@Column(name = "company_name")
	private String cmpName;
	
	@Column(name = "stock")
	private int available;
	
	@Column(name = "purchase_date")
	private String purchaseDate;
	
	private int userId;
	
	public Expense() {
		
	}
	
	
	public Expense(int expenseId, String itemName, float price, String cmpName, int available, String purchaseDate,
			int userId) {
		super();
		this.expenseId = expenseId;
		this.itemName = itemName;
		this.price = price;
		this.cmpName = cmpName;
		this.available = available;
		this.purchaseDate = purchaseDate;
		this.userId = userId;
	}

	

	public String getCmpName() {
		return cmpName;
	}


	public void setCmpName(String cmpName) {
		this.cmpName = cmpName;
	}


	public int getAvailable() {
		return available;
	}


	public void setAvailable(int available) {
		this.available = available;
	}


	public Expense(int expenseId) {
		super();
		this.expenseId = expenseId;
	}

	public int getExpenseId() {
		return expenseId;
	}
	public void setExpenseId(int expenseId) {
		this.expenseId = expenseId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}


	@Override
	public String toString() {
		return expenseId + " " + itemName + " " + price + " "
				+ cmpName + "" + available + " " + purchaseDate + " " + userId ;
	}
	
}
