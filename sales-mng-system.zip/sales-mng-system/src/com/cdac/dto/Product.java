package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	@Id
	@Column(name="pro_id")
	@GeneratedValue
	private int pid;
	@Column(name="pro_name")
	private String pname;
	@Column(name="pro_cost")
	private float cost;
	@Column(name="pro_quant")
	private int quantity;
	
	private int userId;
	public Product() {
	
	}
	public Product(int pid, String pname, float cost, int quantity,int userId) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.cost = cost;
		this.quantity = quantity;
		this.userId=userId;
		
	}
	
	
	public Product(int pid) {
		super();
		this.pid = pid;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return  pid + " " + pname + " " + cost + " " + quantity + " "
				+" " +userId;
	}
}
