package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Expense;
import com.cdac.dto.Product;

public interface ProductDao {
	void insertProduct(Product product);
	List<Product> selectAll(int userId);
	void deleteProduct(int pid);
	Product selectProduct(int pid);
	void updateProduct(Product product);
}
