package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ProductDao;
import com.cdac.dto.Expense;
import com.cdac.dto.Product;

@Service
public class ProductServiceImple implements ProductService {
	@Autowired
	private ProductDao productDao;
	
	
	@Override
	public void addProduct(Product product) {
		
		productDao.insertProduct(product);
		
	}

	@Override
	public List<Product> selectAll(int userId) {
		return productDao.selectAll(userId);
	}
	
	@Override
	public void removeProduct(int pid) {
		productDao.deleteProduct(pid);
	}

	@Override
	public Product findProduct(int pid) {
		return productDao.selectProduct(pid);
	}

	@Override
	public void modifyProduct(Product product) {
		productDao.updateProduct(product);
	}


}
