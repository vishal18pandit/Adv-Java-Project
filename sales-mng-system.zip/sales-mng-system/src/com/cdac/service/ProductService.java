package com.cdac.service;

import java.util.List;

import com.cdac.dto.Expense;
import com.cdac.dto.Product;

public interface ProductService {
	void addProduct(Product product);
	List<Product> selectAll(int userId);
	void removeProduct(int pid);
	Product findProduct(int pid);
	void modifyProduct(Product product);
	
}
